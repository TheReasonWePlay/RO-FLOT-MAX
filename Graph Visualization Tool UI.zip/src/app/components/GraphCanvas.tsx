import { useRef, useState } from 'react';

/**
 * GraphCanvas component renders the flow network as an interactive SVG
 * - Nodes are draggable
 * - Edges show flow/capacity labels
 * - Highlighted paths are shown during algorithm execution
 */

interface Node {
  id: string;
  label: string;
  x: number;
  y: number;
  type: 'source' | 'sink' | 'normal';
}

interface Edge {
  id: string;
  source: string;
  target: string;
  capacity: number;
  flow: number;
}

interface GraphCanvasProps {
  nodes: Node[];
  edges: Edge[];
  selectedNode: string | null;
  selectedEdge: string | null;
  onNodeSelect: (id: string) => void;
  onEdgeSelect: (id: string) => void;
  onNodeMove: (id: string, x: number, y: number) => void;
  highlightedPath?: string[];
}

export function GraphCanvas({ nodes, edges, selectedNode, selectedEdge, onNodeSelect, onEdgeSelect, onNodeMove, highlightedPath = [] }: GraphCanvasProps) {
  const [draggingNode, setDraggingNode] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);

  const handleNodeMouseDown = (e: React.MouseEvent, nodeId: string, nodeX: number, nodeY: number) => {
    e.stopPropagation();
    setDraggingNode(nodeId);
    onNodeSelect(nodeId);

    if (svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      const offsetX = e.clientX - rect.left - nodeX;
      const offsetY = e.clientY - rect.top - nodeY;
      setDragOffset({ x: offsetX, y: offsetY });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggingNode && svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      const x = Math.max(40, Math.min(rect.width - 40, e.clientX - rect.left - dragOffset.x));
      const y = Math.max(40, Math.min(rect.height - 40, e.clientY - rect.top - dragOffset.y));
      onNodeMove(draggingNode, x, y);
    }
  };

  const handleMouseUp = () => {
    setDraggingNode(null);
  };

  const getNodeColor = (node: Node) => {
    if (node.type === 'source') return { fill: '#10b981', stroke: '#059669' };
    if (node.type === 'sink') return { fill: '#ef4444', stroke: '#dc2626' };
    return { fill: '#3b82f6', stroke: '#2563eb' };
  };

  const isEdgeInPath = (edgeId: string) => {
    return highlightedPath.includes(edgeId);
  };

  const renderArrowMarker = (edgeId: string, isSelected: boolean, isInPath: boolean) => {
    const color = isInPath ? '#10b981' : isSelected ? '#3b82f6' : '#6b7280';
    return (
      <defs key={`marker-${edgeId}`}>
        <marker
          id={`arrow-${edgeId}`}
          viewBox="0 0 10 10"
          refX="9"
          refY="5"
          markerWidth="6"
          markerHeight="6"
          orient="auto"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill={color} />
        </marker>
      </defs>
    );
  };

  const calculateEdgePath = (source: Node, target: Node) => {
    const dx = target.x - source.x;
    const dy = target.y - source.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    const nodeRadius = 30;
    const startX = source.x + (dx / distance) * nodeRadius;
    const startY = source.y + (dy / distance) * nodeRadius;
    const endX = target.x - (dx / distance) * (nodeRadius + 10);
    const endY = target.y - (dy / distance) * (nodeRadius + 10);

    return { startX, startY, endX, endY };
  };

  return (
    <svg
      ref={svgRef}
      className="w-full h-full bg-gray-50"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{ display: 'block' }}
    >
      {edges.map(edge => {
        const sourceNode = nodes.find(n => n.id === edge.source);
        const targetNode = nodes.find(n => n.id === edge.target);

        if (!sourceNode || !targetNode) return null;

        const { startX, startY, endX, endY } = calculateEdgePath(sourceNode, targetNode);
        const isSelected = selectedEdge === edge.id;
        const isInPath = isEdgeInPath(edge.id);
        const midX = (startX + endX) / 2;
        const midY = (startY + endY) / 2;

        return (
          <g key={edge.id}>
            {renderArrowMarker(edge.id, isSelected, isInPath)}

            <line
              x1={startX}
              y1={startY}
              x2={endX}
              y2={endY}
              stroke={isInPath ? '#10b981' : isSelected ? '#3b82f6' : '#6b7280'}
              strokeWidth={isInPath ? 4 : isSelected ? 4 : 2}
              markerEnd={`url(#arrow-${edge.id})`}
              className="cursor-pointer transition-all hover:stroke-blue-400"
              onClick={(e) => {
                e.stopPropagation();
                onEdgeSelect(edge.id);
              }}
              style={{
                filter: isInPath ? 'drop-shadow(0 0 4px rgba(16, 185, 129, 0.6))' : isSelected ? 'drop-shadow(0 0 2px rgba(59, 130, 246, 0.5))' : 'none'
              }}
            />

            <rect
              x={midX - 30}
              y={midY - 14}
              width="60"
              height="28"
              rx="6"
              fill={isInPath ? '#d1fae5' : 'white'}
              stroke={isInPath ? '#10b981' : isSelected ? '#3b82f6' : '#d1d5db'}
              strokeWidth={isInPath ? 2 : isSelected ? 2 : 1}
              className="cursor-pointer transition-all"
              onClick={(e) => {
                e.stopPropagation();
                onEdgeSelect(edge.id);
              }}
            />

            <text
              x={midX}
              y={midY + 5}
              textAnchor="middle"
              className="text-sm select-none pointer-events-none font-mono"
              fill={isInPath ? '#065f46' : '#374151'}
            >
              {edge.flow}/{edge.capacity}
            </text>
          </g>
        );
      })}

      {nodes.map(node => {
        const colors = getNodeColor(node);
        const isSelected = selectedNode === node.id;
        const isInPath = highlightedPath.some(edgeId => {
          const edge = edges.find(e => e.id === edgeId);
          return edge && (edge.source === node.id || edge.target === node.id);
        });

        return (
          <g
            key={node.id}
            onMouseDown={(e) => handleNodeMouseDown(e, node.id, node.x, node.y)}
            className="cursor-move"
          >
            <circle
              cx={node.x}
              cy={node.y}
              r="30"
              fill={colors.fill}
              stroke={isInPath ? '#10b981' : isSelected ? '#1e40af' : colors.stroke}
              strokeWidth={isInPath ? 5 : isSelected ? 5 : 2}
              className="transition-all hover:brightness-110 hover:stroke-4"
              style={{
                filter: isInPath ? 'drop-shadow(0 0 8px rgba(16, 185, 129, 0.5))' : isSelected ? 'drop-shadow(0 0 6px rgba(30, 64, 175, 0.6))' : 'none',
                cursor: 'move'
              }}
            />

            <text
              x={node.x}
              y={node.y + 6}
              textAnchor="middle"
              className="text-xl select-none pointer-events-none"
              fill="white"
            >
              {node.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
