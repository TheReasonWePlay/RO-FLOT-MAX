import { useState, useEffect, useRef } from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { Navbar } from './components/Navbar';
import { LeftSidebar } from './components/LeftSidebar';
import { SelectionPanel } from './components/SelectionPanel';
import { GraphCanvas } from './components/GraphCanvas';
import { CapacityTable } from './components/CapacityTable';

/**
 * Node represents a vertex in the flow network graph
 * - source: starting point (labeled α)
 * - sink: ending point (labeled ω)
 * - normal: intermediate nodes (labeled A, B, C, etc.)
 */
interface Node {
  id: string;
  label: string;
  x: number;
  y: number;
  type: 'source' | 'sink' | 'normal';
}

/**
 * Edge represents a directed connection between two nodes
 * with capacity and current flow
 */
interface Edge {
  id: string;
  source: string;
  target: string;
  capacity: number;
  flow: number;
}

/**
 * AlgorithmStep captures the state of the graph at each step
 * of the maximum flow algorithm execution
 */
interface AlgorithmStep {
  edges: Edge[];
  path: string[]; // Edge IDs that form the augmenting path
  message: string; // Description of what happened in this step
  capacitySnapshot: { [edgeId: string]: number }; // Residual capacities
}

// Initial graph setup: source (α) and sink (ω) nodes only
const initialNodes: Node[] = [
  { id: '1', label: 'α', x: 300, y: 150, type: 'source' },
  { id: '2', label: 'ω', x: 700, y: 150, type: 'sink' },
];

const initialEdges: Edge[] = [];

/**
 * Main application component for the Maximum Flow Visualizer
 * Manages the graph state, algorithm execution, and UI layout
 */
export default function App() {
  // Graph state: nodes and edges
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [baseEdges, setBaseEdges] = useState<Edge[]>(initialEdges);

  // Selection state for highlighting
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<string | null>(null);

  // Algorithm results
  const [maxFlow, setMaxFlow] = useState<number | null>(null);

  // Algorithm execution state
  const [algorithmSteps, setAlgorithmSteps] = useState<AlgorithmStep[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false); // Auto-play mode
  const [capacityHistory, setCapacityHistory] = useState<{ [edgeId: string]: number[] }>({});

  // UI mode state
  const [algorithmStarted, setAlgorithmStarted] = useState(false);
  const [stepByStep, setStepByStep] = useState(false);

  // Reference for auto-play interval timer
  const playIntervalRef = useRef<NodeJS.Timeout | null>(null);

  /**
   * Regenerate algorithm steps whenever the base graph structure changes
   */
  useEffect(() => {
    generateAlgorithmSteps();
  }, [baseEdges]);

  /**
   * Update max flow value when reaching the final step
   */
  useEffect(() => {
    if (algorithmSteps.length > 0 && currentStepIndex < algorithmSteps.length) {
      const step = algorithmSteps[currentStepIndex];

      if (currentStepIndex === algorithmSteps.length - 1) {
        const sinkNode = nodes.find(n => n.type === 'sink');
        const totalFlow = step.edges
          .filter(e => e.target === sinkNode?.id)
          .reduce((sum, e) => sum + e.flow, 0);
        setMaxFlow(totalFlow);
      }
    }
  }, [currentStepIndex, algorithmSteps, nodes]);

  /**
   * Auto-play functionality: automatically advance to next step
   * at regular intervals (1.5 seconds)
   */
  useEffect(() => {
    if (isPlaying && currentStepIndex < algorithmSteps.length - 1) {
      playIntervalRef.current = setInterval(() => {
        setCurrentStepIndex(prev => {
          if (prev >= algorithmSteps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 1500);
    } else {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current);
        playIntervalRef.current = null;
      }
      if (currentStepIndex >= algorithmSteps.length - 1) {
        setIsPlaying(false);
      }
    }

    return () => {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current);
      }
    };
  }, [isPlaying, currentStepIndex, algorithmSteps.length]);

  /**
   * Generates all steps of the Ford-Fulkerson algorithm
   * Uses BFS to find augmenting paths from source to sink
   * Records residual capacity at each step for visualization
   */
  const generateAlgorithmSteps = () => {
    if (baseEdges.length === 0) {
      setAlgorithmSteps([]);
      setCapacityHistory({});
      return;
    }

    const steps: AlgorithmStep[] = [];
    const history: { [edgeId: string]: number[] } = {};

    baseEdges.forEach(edge => {
      history[edge.id] = [];
    });

    const workingEdges = baseEdges.map(e => ({ ...e, flow: 0 }));

    const createSnapshot = (edgeList: Edge[]) => {
      const snapshot: { [edgeId: string]: number } = {};
      edgeList.forEach(edge => {
        snapshot[edge.id] = edge.capacity - edge.flow;
      });
      return snapshot;
    };

    const recordHistory = (edgeList: Edge[]) => {
      edgeList.forEach(edge => {
        history[edge.id].push(edge.capacity - edge.flow);
      });
    };

    steps.push({
      edges: workingEdges.map(e => ({ ...e })),
      path: [],
      message: 'Initial state: All flows set to 0',
      capacitySnapshot: createSnapshot(workingEdges)
    });
    recordHistory(workingEdges);

    const sourceNode = nodes.find(n => n.type === 'source');
    const sinkNode = nodes.find(n => n.type === 'sink');

    if (!sourceNode || !sinkNode) {
      setAlgorithmSteps(steps);
      setCapacityHistory(history);
      return;
    }

    const findAugmentingPath = (edges: Edge[], source: string, sink: string): string[] | null => {
      const visited = new Set<string>();
      const queue: { nodeId: string; path: string[] }[] = [{ nodeId: source, path: [] }];

      while (queue.length > 0) {
        const { nodeId, path } = queue.shift()!;

        if (nodeId === sink) {
          return path;
        }

        if (visited.has(nodeId)) continue;
        visited.add(nodeId);

        for (const edge of edges) {
          if (edge.source === nodeId && edge.capacity > edge.flow && !visited.has(edge.target)) {
            queue.push({ nodeId: edge.target, path: [...path, edge.id] });
          }
        }
      }

      return null;
    };

    let iteration = 0;
    const maxIterations = 100;

    while (iteration < maxIterations) {
      const path = findAugmentingPath(workingEdges, sourceNode.id, sinkNode.id);

      if (!path || path.length === 0) break;

      const pathEdges = path.map(id => workingEdges.find(e => e.id === id)!).filter(e => e);
      if (pathEdges.length === 0) break;

      const bottleneck = Math.min(...pathEdges.map(e => e.capacity - e.flow));

      if (bottleneck <= 0) break;

      const pathNodes = [
        pathEdges[0].source,
        ...path.map(id => workingEdges.find(e => e.id === id)!.target)
      ];
      const pathStr = pathNodes.map(id => nodes.find(n => n.id === id)?.label || id).join(' → ');

      steps.push({
        edges: workingEdges.map(e => ({ ...e })),
        path: path,
        message: `Found augmenting path: ${pathStr}`,
        capacitySnapshot: createSnapshot(workingEdges)
      });
      recordHistory(workingEdges);

      path.forEach(edgeId => {
        const edge = workingEdges.find(e => e.id === edgeId);
        if (edge) {
          edge.flow += bottleneck;
        }
      });

      steps.push({
        edges: workingEdges.map(e => ({ ...e })),
        path: path,
        message: `Augmented flow by ${bottleneck} along path ${pathStr}`,
        capacitySnapshot: createSnapshot(workingEdges)
      });
      recordHistory(workingEdges);

      iteration++;
    }

    steps.push({
      edges: workingEdges.map(e => ({ ...e })),
      path: [],
      message: 'No more augmenting paths found. Algorithm complete!',
      capacitySnapshot: createSnapshot(workingEdges)
    });
    recordHistory(workingEdges);

    setAlgorithmSteps(steps);
    setCapacityHistory(history);
    setCurrentStepIndex(0);
  };

  /**
   * Add a new intermediate node to the graph
   */
  const handleAddNode = () => {
    const newId = (Math.max(...nodes.map(n => parseInt(n.id)), 0) + 1).toString();
    const normalNodeCount = nodes.filter(n => n.type === 'normal').length;
    const newNode: Node = {
      id: newId,
      label: String.fromCharCode(65 + normalNodeCount),
      x: 300 + Math.random() * 400,
      y: 100 + Math.random() * 250,
      type: 'normal'
    };
    setNodes([...nodes, newNode]);
  };

  /**
   * Add a new directed edge between two nodes
   */
  const handleAddEdge = (source: string, target: string, capacity: number) => {
    const newId = `e${baseEdges.length + 1}`;
    const newEdge: Edge = {
      id: newId,
      source,
      target,
      capacity,
      flow: 0
    };
    setBaseEdges([...baseEdges, newEdge]);
    setCurrentStepIndex(0);
  };

  /**
   * Delete a node from the graph (only normal nodes can be deleted)
   * Also removes all edges connected to this node
   */
  const handleDeleteNode = (nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node || node.type === 'source' || node.type === 'sink') {
      alert('Cannot delete source or sink nodes');
      return;
    }

    // Remove the node
    setNodes(nodes.filter(n => n.id !== nodeId));

    // Remove all edges connected to this node
    setBaseEdges(baseEdges.filter(e => e.source !== nodeId && e.target !== nodeId));

    // Clear selection
    setSelectedNode(null);
  };

  /**
   * Delete an edge from the graph
   */
  const handleDeleteEdge = (edgeId: string) => {
    setBaseEdges(baseEdges.filter(e => e.id !== edgeId));
    setSelectedEdge(null);
  };

  const handleNodeMove = (id: string, x: number, y: number) => {
    setNodes(nodes.map(node =>
      node.id === id ? { ...node, x, y } : node
    ));
  };

  const handleReset = () => {
    setNodes(initialNodes);
    setBaseEdges(initialEdges);
    setMaxFlow(null);
    setSelectedNode(null);
    setSelectedEdge(null);
    setCurrentStepIndex(0);
    setIsPlaying(false);
    setAlgorithmStarted(false);
  };

  const handleBackToResolution = () => {
    setAlgorithmStarted(false);
    setCurrentStepIndex(0);
    setIsPlaying(false);
    setMaxFlow(null);
  };

  const handleStartAlgorithm = () => {
    if (baseEdges.length === 0) {
      alert('Please add at least one edge before starting the algorithm');
      return;
    }

    setAlgorithmStarted(true);
    setSelectedNode(null);
    setSelectedEdge(null);

    if (!stepByStep) {
      const finalStepIndex = algorithmSteps.length - 1;
      setCurrentStepIndex(finalStepIndex);

      if (algorithmSteps.length > 0) {
        const finalStep = algorithmSteps[finalStepIndex];
        const totalFlow = finalStep.edges
          .filter(e => {
            const targetNode = nodes.find(n => n.id === e.target);
            return targetNode?.type === 'sink';
          })
          .reduce((sum, e) => sum + e.flow, 0);
        setMaxFlow(totalFlow);
      }
    } else {
      setCurrentStepIndex(0);
    }
  };

  const handleNextStep = () => {
    if (currentStepIndex < algorithmSteps.length - 1) {
      const newIndex = currentStepIndex + 1;
      setCurrentStepIndex(newIndex);

      if (newIndex === algorithmSteps.length - 1) {
        const step = algorithmSteps[newIndex];
        const totalFlow = step.edges
          .filter(e => {
            const targetNode = nodes.find(n => n.id === e.target);
            return targetNode?.type === 'sink';
          })
          .reduce((sum, e) => sum + e.flow, 0);
        setMaxFlow(totalFlow);
      }
    }
  };

  const handlePreviousStep = () => {
    if (currentStepIndex > 0) {
      const newIndex = currentStepIndex - 1;
      setCurrentStepIndex(newIndex);
    }
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const currentStep = algorithmSteps[currentStepIndex];
  const displayEdges = currentStep?.edges || baseEdges;
  const highlightedPath = currentStep?.path || [];

  const selectedNodeData = selectedNode ? nodes.find(n => n.id === selectedNode) : null;
  const selectedEdgeData = selectedEdge ? displayEdges.find(e => e.id === selectedEdge) : null;

  return (
    <div className="size-full flex flex-col bg-gray-50">
      <Navbar onReset={handleReset} />

      <div className="flex-1 flex overflow-hidden">
        <LeftSidebar
          onAddNode={handleAddNode}
          onAddEdge={handleAddEdge}
          onNextStep={handleNextStep}
          onPreviousStep={handlePreviousStep}
          onPlayPause={handlePlayPause}
          onStartAlgorithm={handleStartAlgorithm}
          onBackToResolution={handleBackToResolution}
          isPlaying={isPlaying}
          canStepForward={currentStepIndex < algorithmSteps.length - 1}
          canStepBackward={currentStepIndex > 0}
          currentStep={currentStepIndex}
          totalSteps={algorithmSteps.length - 1}
          nodes={nodes}
          algorithmStarted={algorithmStarted}
          stepByStep={stepByStep}
          onStepByStepChange={setStepByStep}
        />

        {/* Main content area: Graph, Capacity Table, and Selection Panel */}
        <div className="flex-1 flex overflow-hidden">
          {/* Graph and Table section */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <PanelGroup direction="vertical" className="flex-1">
              {/* Graph visualization panel */}
              <Panel defaultSize={50} minSize={30}>
                <div className="h-full p-6 pb-3 pr-3">
                  <div className="h-full bg-white rounded-xl shadow-lg border border-border overflow-hidden">
                    <GraphCanvas
                      nodes={nodes}
                      edges={displayEdges}
                      selectedNode={selectedNode}
                      selectedEdge={selectedEdge}
                      onNodeSelect={setSelectedNode}
                      onEdgeSelect={setSelectedEdge}
                      onNodeMove={handleNodeMove}
                      highlightedPath={highlightedPath}
                    />
                  </div>
                </div>
              </Panel>

              {/* Show capacity table in both modes when algorithm has started */}
              {algorithmStarted && (
                <>
                  <PanelResizeHandle className="h-2 bg-border hover:bg-blue-400 transition-colors cursor-row-resize relative group">
                    <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex items-center justify-center">
                      <div className="w-12 h-1 bg-muted-foreground/30 rounded group-hover:bg-blue-500 transition-colors"></div>
                    </div>
                  </PanelResizeHandle>

                  {/* Residual Capacity Table - visible in both modes */}
                  <Panel defaultSize={50} minSize={20}>
                    <div className="h-full px-6 pt-3 pb-6 pr-3 overflow-auto">
                      <CapacityTable
                        edges={baseEdges}
                        capacityHistory={capacityHistory}
                        currentStep={currentStepIndex}
                        getNodeLabel={(id) => nodes.find(n => n.id === id)?.label || ''}
                      />
                    </div>
                  </Panel>
                </>
              )}
            </PanelGroup>
          </div>

          {/* Selection Panel - Right side */}
          <SelectionPanel
            selectedNode={selectedNodeData}
            selectedEdge={selectedEdgeData ? {
              id: selectedEdgeData.id,
              source: nodes.find(n => n.id === selectedEdgeData.source)?.label || '',
              target: nodes.find(n => n.id === selectedEdgeData.target)?.label || '',
              capacity: selectedEdgeData.capacity,
              flow: selectedEdgeData.flow
            } : null}
            onDeleteNode={handleDeleteNode}
            onDeleteEdge={handleDeleteEdge}
            algorithmStarted={algorithmStarted}
          />
        </div>
      </div>
    </div>
  );
}
